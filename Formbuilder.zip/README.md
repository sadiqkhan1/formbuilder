# Frontend-Assignment

### Prerequisites
Run the following commands to install the necessary dependencies and start the app:
- `npm install`
- `npm start`

This will start a webpack DevServer which allows you to access the app under http://localhost:3000.
